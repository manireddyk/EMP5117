package demo.example.demo.rest;

import java.time.LocalDateTime;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class FunRestController {
	@Value("${mobiles.Apple}")
	private ArrayList<String> propName;
	@Value("${mobiles.Nokia}")
	private ArrayList<String> propName2;
	@Value("${mobiles.Samsung}")
	private ArrayList<String> propName3;
	@Value("${Adapter}")
	private ArrayList<String> propName4;

	@GetMapping("/DisplayPropNames")
	public String DisplayPropNames()
	{
		return "<b>Welcome to Inventory Information System</b></br>"+

				propName+"->Total Apple products:"+propName.size()+" <a href='http://localhost:9090/addProdApple\'>Add Apple prodcuts to inventory</a> &nbsp&nbsp"+" <a href='http://localhost:9090/delProdApple\'>Reduce Apple Products inventory</a><br>"
				+propName2+"->Total Nokia  products:"+propName2.size()+" <a href='http://localhost:9090/addProdNokia\'>Add Nokia prodcuts to inventory</a> &nbsp&nbsp"+" <a href='http://localhost:9090/delProdNokia\'>Reduce Nokia Products inventory</a> <br>"
				+propName3+"->Total Samsung  products:"+propName3.size()+" <a href='http://localhost:9090/addProdSamsung\'>Add Samsung prodcuts to inventory</a> &nbsp&nbsp"+" <a href='http://localhost:9090/delProdSamsung\'>Reduce Samsung Products inventory</a> <br>"
				+propName4+"->Total Adapter  products:"+propName4.size()+" <a href='http://localhost:9090/addProdAdapter\'>Add Adapter prodcuts to inventory</a> &nbsp&nbsp"+" <a href='http://localhost:9090/delProdAdapter\'>Reduce Adapter Products inventory</a>";
	}
	@GetMapping("/delProdApple")
	public String delProdApple()
	{
		return " Succesfully Deleted:"+propName.remove(0);

	}
	@GetMapping("/delProdNokia")
	public String delProdNokia()
	{
		return " Succesfully Deleted:"+propName2.remove(0);
	}
	@GetMapping("/delProdSamsung")
	public String delProdSamsung()
	{
		return " Succesfully Deleted:"+propName3.remove(0);
	}
	@GetMapping("/delProdAdapter")
	public String delProdAdapter()
	{
		return " Succesfully Deleted:"+propName4.remove(0);
	}
	@GetMapping("/addProdApple")
	public String addProdApple()
	{
		return " Succesfully Added:"+propName.add("iPhone 8");
	}
	@GetMapping("/addProdNokia")
	public String addProdNokia()
	{
		return " Succesfully Added:"+propName2.add("Nokia X");
	}
	@GetMapping("/addProdSamsung")
	public String addProdSamsung()
	{
		return " Succesfully Added:"+propName3.add("Samsung S9");
	}
	@GetMapping("/addProdAdapter")
	public String addProdAdapter()
	{
		return " Succesfully Added:"+propName4.add("Adapter");
	}

}
